#ifndef BLINKER_H
#define BLINKER_H

#if defined(BLINKER_BLE)

    #if defined(BLINKER_ALIGENIE_LIGHT) || defined(BLINKER_ALIGENIE_OUTLET) || \
        defined(BLINKER_ALIGENIE_SWITCH)|| defined(BLINKER_ALIGENIE_SENSOR)
        #error This code is intended to run on the BLINKER_MQTT mode! Please check your mode setting.    
    #endif

    #if defined(BLINKER_DUEROS_LIGHT) || defined(BLINKER_DUEROS_OUTLET) || \
        defined(BLINKER_DUEROS_SWITCH)|| defined(BLINKER_DUEROS_SENSOR)
        #error This code is intended to run on the BLINKER_MQTT mode! Please check your mode setting.
    #endif

    #if defined(ESP32)
        #include "BlinkerESP32BLE.h"

        BlinkerESP32BLE     Blinker;
    #else
        #include "BlinkerSerialBLE.h"

        BlinkerSerialBLE    Blinker;
    #endif

#elif defined(BLINKER_WIFI) || defined(BLINKER_MQTT)

    #if defined(BLINKER_WIFI)
        #undef BLINKER_WIFI
        #define BLINKER_MQTT
    #endif

    #include "BlinkerAssistant.h"

    #if (defined(ESP8266) || defined(ESP32)) && !defined(BLINKER_MQTT_AT)
        #include "BlinkerESPMQTT.h"

        BlinkerESPMQTT      Blinker;     
    #else
        #define BLINKER_ESP_AT

        #define BLINKER_MQTT_AT

        #undef BLINKER_MQTT
        
        #include "BlinkerSerialESPMQTT.h"

        BlinkerSerialESPMQTT      Blinker;  
    #endif

// #elif defined(BLINKER_WIFI_LOWPOWER)

//     #if defined(ESP8266) || defined(ESP32)
//         #include "BlinkerESPMQTTLP.h"

//         BlinkerESPMQTTLP    Blinker;
//     #endif

#elif defined(BLINKER_PRO)

    #if defined(BLINKER_ALIGENIE_LIGHT) || defined(BLINKER_ALIGENIE_OUTLET) || \
        defined(BLINKER_ALIGENIE_SWITCH)|| defined(BLINKER_ALIGENIE_SENSOR)
        #error This code is intended to run on the BLINKER_MQTT mode! Please check your mode setting.
    #endif    

    #if defined(BLINKER_DUEROS_LIGHT) || defined(BLINKER_DUEROS_OUTLET) || \
        defined(BLINKER_DUEROS_SWITCH)|| defined(BLINKER_DUEROS_SENSOR)
        #error This code is intended to run on the BLINKER_MQTT mode! Please check your mode setting.
    #endif

    #define BLINKER_ALIGENIE

    #define BLINKER_DUEROS

    #ifndef BLINKER_ESP_SMARTCONFIG
        #ifndef BLINKER_APCONFIG
            #define BLINKER_ESP_SMARTCONFIG
        #endif
    #endif

    #if defined(ESP8266) || defined(ESP32)
        #include "BlinkerESPPRO.h"
        
        BlinkerESPPRO       Blinker; 
    #else
        #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
    #endif

#elif defined(BLINKER_PRO_ESP) || defined(BLINKER_WIFI_AUTO)

    #include "BlinkerAssistant.h"

    #if defined(BLINKER_WIFI_AUTO)
        #define BLINKER_PRO_ESP
    #endif

    // #ifndef BLINKER_ESP_SMARTCONFIG
    //     #ifndef BLINKER_APCONFIG
    //         #define BLINKER_ESP_SMARTCONFIG
    //     #endif
    // #endif

    #if defined(ESP8266) || defined(ESP32)
        #include "BlinkerESPPROESP.h"
        
        BlinkerESPPROESP    Blinker; 
    #else
        #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
    #endif

#elif defined(BLINKER_AT_MQTT)

    #define BLINKER_ESP_AT

    #if defined(ESP8266) || defined(ESP32)
        #include "BlinkerESPMQTTAT.h"

        BlinkerESPMQTTAT    Blinker; 
    #else
        #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
    #endif

#elif defined(BLINKER_WIFI_GATEWAY)

    #include "BlinkerAssistant.h"

    #if defined(ESP8266) || defined(ESP32)
        #include "BlinkerESPGateway.h"

        BlinkerESPGateway    Blinker; 
    #else
        #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
    #endif

#elif defined(BLINKER_WIFI_SUBDEVICE)

    #include "BlinkerAssistant.h"

    #if defined(ESP8266) || defined(ESP32)
        #include "BlinkerESPSubDevice.h"

        BlinkerESPSubDevice     Blinker;
    #else
        #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
    #endif

#elif defined(BLINKER_NBIOT_WH)

    #ifndef BLINKER_NB73_NBIOT
    #define BLINKER_NB73_NBIOT
    #endif

    #include "BlinkerSerialWHNBIoT.h"

    BlinkerSerialWHNBIoT    Blinker;

#elif defined(BLINKER_NBIOT_SIM7020)

    // #ifndef BLINKER_SIM7020C_NBIOT
    // #define BLINKER_SIM7020C_NBIOT
    // #endif

    #include "BlinkerSerialSIMNBIoT.h"

    BlinkerSerialSIMNBIoT   Blinker;

#elif defined(BLINKER_PRO_SIM7020)

    #include "BlinkerSIMPRO.h"

    BlinkerSIMPRO   Blinker;

#elif defined(BLINKER_GPRS_AIR202)

    // #ifndef BLINKER_AIR202_GPRS
    // #define BLINKER_AIR202_GPRS
    // #endif

    #include "BlinkerSerialLUATGPRS.h"

    BlinkerSerialLUATGPRS   Blinker;

#elif defined(BLINKER_PRO_AIR202)

    #include "BlinkerLUATPRO.h"

    BlinkerLUATPRO  Blinker;

// #elif defined(BLINKER_WIFI_AUTO)

//     #define BLINKER_MQTT_AUTO

//     #if !defined(BLINKER_ESP_SMARTCONFIG) && !defined(BLINKER_APCONFIG)
//         #define BLINKER_ESP_SMARTCONFIG
//     #endif

//     #include "BlinkerESPMQTTAUTO.h"

//     BlinkerESPMQTTAUTO  Blinker;

#elif defined(BLINKER_LOWPOWER_AIR202)
    
    #include "BlinkerLowPowerGPRS.h"

    BlinkerLowPowerGPRS Blinker;
    
#else

    #error Please set a mode BLINKER_BLE/BLINKER_WIFI/BLINKER_MQTT ! Please check your mode setting.

#endif

#include "BlinkerWidgets.h"

// #if defined(BLINKER_MQTT)
#if defined(BLINKER_ESP_TASK)
#if defined(ESP8266)
    #error ESP8266 TASK NOT SUPPORT!
    // #include "Schedule.h"
    // extern "C" {
    // #include "ets_sys.h"
    // #include "user_interface.h"
    // #include "cont.h"
    // }

    // #define blinker_procTaskPrio        1
    // #define blinker_procTaskQueueLen    1
    // os_event_t    blinker_procTaskQueue[blinker_procTaskQueueLen];
    // cont_t* blinker_g_pcont __attribute__((section(".noinit")));

    // // uint32_t oldtime = 0;
    // // static uint32_t s_micros_at_task_start;

    // // static uint32_t oldtime = 0;

    // void preloop_update_frequency() __attribute__((weak));
    // void preloop_update_frequency() {
    // #if defined(F_CPU) && (F_CPU == 160000000L)
    //     REG_SET_BIT(0x3ff00014, BIT(0));
    //     ets_update_cpu_frequency(160);
    // #endif
    // }

    // static bool isInit = false;

    // static void blinker_loop_wrapper() {
    //     preloop_update_frequency();
    //     if (!isInit)
    //     {
    //         Blinker.beginMQTT();
    //         isInit = true;
    //     }
    //     else
    //     {
    //         Blinker.run();
    //     }
    //     // Blinker.run();
    //     run_scheduled_functions();
    //     // esp_schedule();
    // }

    // static void blinker_run(os_event_t *events)
    // {
    //     cont_run(blinker_g_pcont, &blinker_loop_wrapper);
    //     system_os_post(blinker_procTaskPrio, 0, (os_param_t)blinker_g_pcont);
    // }

    // void BLINKER_TAST_INIT()
    // {
    //     // ets_task
    //     // #if defined(BLINKER_MQTT)
    //     //     Blinker.beginMQTT();
    //     // #endif
    //     system_os_task(blinker_run, blinker_procTaskPrio, blinker_procTaskQueue, blinker_procTaskQueueLen);
    //     system_os_post(blinker_procTaskPrio, 0, (os_param_t)blinker_g_pcont);
    // }
// #endif

// #endif

// #if defined(ESP32)
#elif defined(ESP32)
    #include <freertos/FreeRTOS.h>
    #include <freertos/task.h>
    #include <Arduino.h>

    // #if CONFIG_AUTOSTART_ARDUINO

    #if CONFIG_FREERTOS_UNICORE
    #define ARDUINO_RUNNING_CORE 0
    #else
    #define ARDUINO_RUNNING_CORE 1
    #endif



// #include <ESPWiFi.h>
// #include <ESPHTTPClient.h>
// #include <JsonListener.h>

// // time
// #include <time.h>                       // time() ctime()
// #include <sys/time.h>                   // struct timeval
// #include <coredecls.h>                  // settimeofday_cb()

// #include "SSD1306Wire.h"
// #include "OLEDDisplayUi.h"
// #include "Wire.h"
// #include "OpenWeatherMapCurrent.h"
// #include "OpenWeatherMapForecast.h"
// #include "WeatherStationFonts.h"
// #include "WeatherStationImages.h"

// /***************************
//  * Begin Settings
//  **************************/

// // WIFI
// const char* WIFI_SSID = "HUAWEI-ZHAO";
// const char* WIFI_PWD = "13958469997";

// #define TZ              7       // (utc+) TZ in hours
// #define DST_MN          60      // use 60mn for summer time in some countries

// const int UPDATE_INTERVAL_SECS = 20 * 60; // Update every 20 minutes
// const int I2C_DISPLAY_ADDRESS = 0x3c;
// const int SDA_PIN = 23; 
// const int SDC_PIN = 19; 
// const int RESET_PIN = 18; 


// String OPEN_WEATHER_MAP_APP_ID = "2aced3871f56fdb75c0c70295fc5169e";
// String OPEN_WEATHER_MAP_LOCATION_ID = "1804442";
// String OPEN_WEATHER_MAP_LANGUAGE = "zh_cn";
// const uint8_t MAX_FORECASTS = 4;
// const boolean IS_METRIC = true;
// // Adjust according to your language
// const String WDAY_NAMES[] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
// const String MONTH_NAMES[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};

// /***************************
//  * End Settings
//  **************************/
// SSD1306Wire     display(I2C_DISPLAY_ADDRESS, SDA_PIN, SDC_PIN);
// OLEDDisplayUi   ui( &display );
 
// OpenWeatherMapCurrentData currentWeather;
// OpenWeatherMapCurrent currentWeatherClient;

// OpenWeatherMapForecastData forecasts[MAX_FORECASTS];
// OpenWeatherMapForecast forecastClient;

// #define TZ_MN           ((TZ)*60)
// #define TZ_SEC          ((TZ)*3600)
// #define DST_SEC         ((DST_MN)*60)
// time_t now;

// // flag changed in the ticker function every 10 minutes
// bool readyForWeatherUpdate = false;

// String lastUpdate = "--";

// long timeSinceLastWUpdate = 0;

// //declaring prototypes
// void drawProgress(OLEDDisplay *display, int percentage, String label);
// void updateData(OLEDDisplay *display);
// void drawDateTime(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y);
// void drawCurrentWeather(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y);
// void drawForecast(OLEDDisplay *display, OLEDDisplayUiState* state, int16_t x, int16_t y);
// void drawForecastDetails(OLEDDisplay *display, int x, int y, int dayIndex);
// void drawHeaderOverlay(OLEDDisplay *display, OLEDDisplayUiState* state);
// void setReadyForWeatherUpdate();

// FrameCallback frames[] = { drawDateTime, drawCurrentWeather, drawForecast };
// int numberOfFrames = 3;
// OverlayCallback overlays[] = { drawHeaderOverlay };
// int numberOfOverlays = 1;


    void blinkerLoopTask(void *pvParameters)
    {
//         Serial.begin(115200);
//         Serial.println();
//         Serial.println();
//         Serial.print("blinkerLoopTask() function running on core: ");
//         Serial.println(xPortGetCoreID());
//         //  Serial.print("setup() function running on core: ");
//         //  Serial.println(xPortGetCoreID());
//         // oled reset
//         pinMode(RESET_PIN, OUTPUT);
//         digitalWrite(RESET_PIN, LOW);
//         delay(200);
//         digitalWrite(RESET_PIN, HIGH);

//         // initialize dispaly
//         display.init();
//         display.clear();
//         display.display();
//         display.flipScreenVertically();
//         //display.flipScreenVertically();
//         display.setFont(ArialMT_Plain_10);
//         display.setTextAlignment(TEXT_ALIGN_CENTER);
//         display.setContrast(255);

//         // WiFi.begin(WIFI_SSID, WIFI_PWD);

//         int counter = 0;
//         // while (WiFi.status() != WL_CONNECTED) 
//         while (!Blinker.connected()) 
//         {
//             delay(500);
//             Serial.print(".");
//             display.clear();
//             display.drawString(64, 10, "Connecting to WiFi");
//             display.drawXbm(46, 30, 8, 8, counter % 3 == 0 ? activeSymbole : inactiveSymbole);
//             display.drawXbm(60, 30, 8, 8, counter % 3 == 1 ? activeSymbole : inactiveSymbole);
//             display.drawXbm(74, 30, 8, 8, counter % 3 == 2 ? activeSymbole : inactiveSymbole);
//             display.display();
//             counter++;
//         }
//         // Get time from network time service
//         configTime(TZ_SEC, DST_SEC, "pool.ntp.org");

//         ui.setTargetFPS(30);

//         ui.setActiveSymbol(activeSymbole);
//         ui.setInactiveSymbol(inactiveSymbole);

//         // You can change this to
//         // TOP, LEFT, BOTTOM, RIGHT
//         ui.setIndicatorPosition(BOTTOM);

//         // Defines where the first frame is located in the bar.
//         ui.setIndicatorDirection(LEFT_RIGHT);

//         // You can change the transition that is used
//         // SLIDE_LEFT, SLIDE_RIGHT, SLIDE_TOP, SLIDE_DOWN
//         ui.setFrameAnimation(SLIDE_LEFT);

//         ui.setFrames(frames, numberOfFrames);

//         ui.setOverlays(overlays, numberOfOverlays);

//         // Inital UI takes care of initalising the display too.
//         ui.init();
//         display.flipScreenVertically();
//         Serial.println("");

//         updateData(&display);

        for(;;)
         {
//             // Blinker.run();
//             // vTaskDelay(1);
//             //  Serial.print("loop() function running on core: ");
//             //  Serial.println(xPortGetCoreID());
//             if (millis() - timeSinceLastWUpdate > (1000L*UPDATE_INTERVAL_SECS)) {
//                 setReadyForWeatherUpdate();
//                 timeSinceLastWUpdate = millis();
//             }

//             if (readyForWeatherUpdate && ui.getUiState()->frameState == FIXED) {
//                 updateData(&display);
//             }

//             int remainingTimeBudget = ui.update();

//             if (remainingTimeBudget > 0) {
//                 // You can do some work here
//                 // Don't do stuff if you are below your
//                 // time budget.
//                 delay(remainingTimeBudget);
//             }
        }
    }

    extern "C" void BLINKER_TAST_INIT()
    {
        // initArduino();
        // #if defined(BLINKER_MQTT)
        //     Blinker.beginMQTT();
        // #endif
        xTaskCreatePinnedToCore(blinkerLoopTask, 
                                "blinkerLoopTask", 
                                8192, 
                                NULL, 
                                3, 
                                NULL, 
                                1);
    }

    // #endif
#else
    #error This code is intended to run on the ESP8266/ESP32 platform! Please check your Tools->Board setting.
#endif

#endif

#ifndef LED_BUILTIN
    #if defined(ESP8266) || defined(ESP32)
        #define LED_BUILTIN 2
    #else
        #define LED_BUILTIN 13
    #endif
#endif

#endif
